/** 
 * Creating log function to store logs using sql
 * This program is an integration towards accessing the objects of book class
 * 
 * Note: Getters and Setters have been generated generated and to string method is used to overide the method. 
 *  
 * @author Ramkrishna Dakwa (Great Learning FSD 10th Batch)
 * @version 17.0 
 * @since 2nd April 2022 
 */

package Logger;
import java.util.logging.*;
public class Mylogger {
	public static Logger logger = Logger.getLogger("MyLog");
	static{
		FileHandler fh;
		try {
//			fh= new FileHandler("E:/LogDatas/mylogfile.log",true);
			fh=new FileHandler(System.getProperty("user.dir")+System.getProperty("file.separator")+"MyLogFile.log",true);
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger.info("Logger Initialized");
			
		}catch (Exception e) {
			// TODO: handle exception
			logger.log(Level.WARNING,"Excepption :: ",e);
		}
	}
	
//	public static void main(String[] args) {
//		init();
//		try {
//			int a =10/0;
//		}catch (Exception e) {
//			// TODO: handle exception
//			logger.log(Level.WARNING,"Exception ::",e);
//		}
//		logger.info("End of the program");
//	}
	
	public static void writeTolog(String msg) {
		logger.info(msg);
	}
	public static void writeTolog(String msg,Exception e) {
		logger.log(Level.WARNING,msg);
		
	}

}
